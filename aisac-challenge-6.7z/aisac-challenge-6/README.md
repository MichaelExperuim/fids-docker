# Challenge 6

## Build Status

[![pipeline status](https://gitlab.com/aisac-ctf/aisac-challenge-6/badges/master/pipeline.svg)](https://gitlab.com/aisac-ctf/aisac-challenge-6/-/commits/master)

## Overview

This project contains all of the necessary components to build the docker images to be used in challenge 6. The components are:
  
  - 3 images
    - flight information display (FIDS) application server
      - [ubuntu](https://hub.docker.com/_/ubuntu/)
      - configured in dockerfile-app
      - deployment details configured in start.sh or docker-compose.yml depending on deploy strategy
    - FIDS database server
      - [mariadb:10.7.4-focal](https://hub.docker.com/_/mariadb/)
      - configured in dockerfile-db
      - deployment details configured in start.sh or docker-compose.yml depending on deploy strategy
    - participant machine 
      - [kalilinux/kali-rolling:latest](https://hub.docker.com/r/kalilinux/kali-rolling/tags)
      - configured in dockerfile-kali
      - deployment details configured in start.sh or docker-compose.yml depending on deploy strategy
  - 2 bridge networks
    - configured in start.sh 

## Development

The master branch is protected and cannot be pushed to. Please create, work, and push to a dev branch, e.g. `dev-james` or `dev-fixing-issue-12`. We will use the master branch to bring all of our changes together.

### Test

To test project run  `docker-compose up` from the project folder. This command will use the instructions contained in the docker-compose.yml file to build image(s) out of each service block in the file. For more information about docker-compose [visit their documentation](https://docs.docker.com/compose/). 

Alternatively privileged `start.sh` can be used to build and deploy the project as well.


### CICD Pipeline

- TODO 


## Development Machine Requirements

 - [docker](https://docs.docker.com/engine/install/)
 - [docker-compose](https://docs.docker.com/compose/install)

