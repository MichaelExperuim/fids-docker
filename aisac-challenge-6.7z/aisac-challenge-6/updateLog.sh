#!/bin/bash

echo "starting updateLog.sh" >&2

while :
do
    sleep 1m
    date >> /var/log/FIDS_Log.txt
    nc -zv web-server 5000 >> /var/log/FIDS_Log.txt 2>&1
    nc -zv web-server 3306 >> /var/log/FIDS_Log.txt 2>&1
    echo -e "\n" >> /var/log/FIDS_Log.txt
done