#!/bin/bash

app="ctf-6"

# create network (internal)
docker network create -d bridge \
                      --subnet 172.16.245.0/24 \
                      --internal \
                      ${app}.network-internal

# create network (external) 
docker network create -d bridge \
                      --subnet 172.16.248.0/24 \
                      ${app}.network-external


# build db image
docker build -t ${app}.db -f dockerfile-db . 

# run db container
docker run -d \
           --publish 3306:3306/tcp \
           --name=${app}.db \
           --restart=always \
           --network="${app}.network-internal" \
           --ip=172.16.245.32 \
           --hostname="database-server" \
           ${app}.db:latest
           ##--rm \ # this automatically clean up the container and remove the file system when the container exits
           ##--security-opt no-new-privileges 

# build flask app image 
docker build -t ${app}.app -f dockerfile-app .

# run flask app container
docker run -d \
           --publish 5000:5000/tcp \
           --name=${app}.app \
           --network="${app}.network-external" \
           --ip="172.16.248.12" \
           --restart=always \
           --hostname="flight-information-display-app-server" \
           ${app}.app:latest
           #--read-only \
           #--rm \ # this automatically clean up the container and remove the file system when the container exits
           #--security-opt no-new-privileges \

# connect app to internal network
docker network connect ${app}.network-internal ${app}.app --ip="172.16.245.12"

# build kali linux
docker build -t ${app}.kali -f dockerfile-kali .

# run kali linux
docker run -td \
           --name=${app}.kali \
           --restart=always \
           --network="${app}.network-external" \
           --ip="172.16.248.13" \
           ${app}.kali:latest 

