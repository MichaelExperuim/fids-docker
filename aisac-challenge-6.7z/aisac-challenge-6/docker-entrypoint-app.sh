#!/bin/bash

# enable ssh to restart on boot and start ssh
systemctl enable ssh 
service ssh restart

# start shell script
exec /usr/local/bin/updateLog.sh &

# start tcp server 
python3 /usr/local/bin/server.py &

# waits until the DB server port is alive
while ! nc -z fids-db 3306; do
  echo 'waiting for db server...'
  sleep 1
done

# correct acl
setfacl -m g:envmod:rw /etc/environment
chown -R root:root /app
chmod 444 /app/templates/index.html
chmod 755 /app/templates/
chmod 755 /app/static/
chmod 740 /usr/local/bin/docker-entrypoint.sh

# stay open even afte app fails
tail -f /dev/null