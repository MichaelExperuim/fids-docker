# AISAC - GREY HAT INSTRUCTIONS - CHALLENGE 6

## Environment

 - kali linux machine (initial terminal)
 - ubuntu web server
   - key components:
     - `/usr/local/bin/server.py` with root permissions, listening for traffic on port 28493
     - environment variable, `FIDS_DATABASE_PWD`, has been changed which causes flask appliction (FIDS display) to not function
 - mariadb server
   - correct `FIDS_DATABASE_PWD` value is contained in `bash_history` of Brian.Vasquez on the fids-db server

## Goal 

Restore the FIDS display by escalating priveleges to be able to edit `FIDS_DATABASE_PWD` with the correct value.

## FLAGS

  - ubuntu web server:
    - `/flag`
    - `/home/Anna.Richardson/flag`
  - mariadb server:
    - `/home/Brian.Vasquez/flag`

## Question(s)

### Easy - Network Scanning

1. What is the hostname of the web server in this challenge?
2. What is the flag in the user Anna Richardson's home directory?
3. What is the name of the custom remote IT management service?
4. What is the pin to use the remote IT management service?
5. What is the hostname of the database server in this challenge?

### Medium - Privilege Escalation

1. What is the flag in the web-server host root directory?
2. What is the employee name who has access to the database server?

### Hard - Fix the FIDS app Network

1. What is the flight number of the first departing ERAU flight of the day?
2. Where is the gate of the last arriving ERAU flight of the day?
3. What is the flag contained in the FIDS display?

## Suggested Paths of Investigation

## 01 - find ip cidr

command:

`ifconfig`

why:

- learn about network
  - ip address
  - can calculate cidr block of network (?todo:verify)

result:

 - cidr block to be feed into nmap

## 02 - find web server

command:

`nmap [cidr-block]`

why:

 - scan local network for other devices and protocols in use

result:

 - discover web server

## 03 - ssh into web server

command:

`ssh Anna.Richardson@[hostname-db-server]`

or

`ssh Anna.Richardson@[ip-address-db-server]`

password:

`cessna172!`

why:

 - use secure shell (ssh) to connect to database server

result:

 - gain access to web server as user Anna.Richardson

## 04 - connect to tcp server

** this can be performed from the kali machine or within the web-server

command:

`nc web-server 12375`

prompted for pin:

`5880`

why:

 - use netcat to communicate with the web-server on port 28493 using tcp

result:

 - prompted with the user interface of remote IT management software

## 05 - utilize tcp server to elevate privileges 

**see notes section for info on the setup of the /etc/environment file and how it pertains to this task.

command:

`bash usermod -a -G envmod Anna.Richardson`
`bash chmod 444 /flag`

why:

 - add the Anna Richardson to the envmod group. 
 - change permissions of `/flag` so other users have read access

result:

 - enables the user Anna Richardson to edit the `/etc/environment` file. 
 - retrieve `/flag`

## 06 - ssh into database server

command:

`ssh Brian.Vasquez@[hostname-db-server]`

or

`ssh Brian.Vasquez@[ip-address-db-server]`

password:

`callsign702#`

why:

 - use secure shell (ssh) to connect to database server

result:

 - gain access to db server as user Brian.Vasquez

## 07 - analyze .bash_history file

command(s):

`cat /home/Brian.Vasquez/.bash_history`

`history` * when logged in as Brian.Vasquez

why:

 - identify in the `.bash_history` of Brian Vasquez where he accidentally typed his password onto the command prompt.

result:

 - retreive password for database

## 08 - correct issue with flask configuration

command(s):

`vim /etc/environment`

 - edit file so: `FIDS_DATABASE_PWD=m5M5nhgm9mGM4MukVaHVL7tKUbORSvGWzOUJl4IqEgUOd4mOcg`
 - logout and back in again to allow `/etc/environment` to reload
   - `ssh Anna.Richardson@[hostname-db-server]`

`python3 /app/main.py &`

why:
 - Anna.Richardson has been added to the `envmod` group and can now edit the environment variables in `/etc/environment`
 - launch the fids application, `main.py`, as a background process

result:
  - refresh the browser control in cyber skyline. The fids display is restored!

## Hints

 - Can a file be owned by multiple groups in the Ubuntu Linux environment?
 - What system process related aspect did the hackers change to stop the flight information display from working?
 - What database related service did Brian incorrectly run via his terminal on the database server?

### Notes

In Ubuntu a user cannot be added to the root group, which is typically the owner of the /etc/environment file. 
To get around this on the web server the `/etc/environment` file is owned by two groups, `root` and `envmod`, if a user is 
successfully added to the `envmod` group they can edit the `/etc/environment` file. To list the all of the ownership 
information (e.g. multiple groups) use `getfacl /etc/environment`. The command `ls -la` only lists the first 
ownership group of a file.
