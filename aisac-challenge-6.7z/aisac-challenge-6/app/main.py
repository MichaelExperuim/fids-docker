import os
import datetime
from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
import waitress
import logging

logger = logging.getLogger('waitress')
logger.setLevel(logging.DEBUG)

app = Flask(__name__)

db_uri = 'mysql+pymysql://root:%s@fids-db:3306/SDIF' % os.environ['FIDS_DATABASE_PWD']

app.config['SQLALCHEMY_DATABASE_URI'] = db_uri # can use docker container name or ip address
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Flight(db.Model):
    __tablename__ = 'vwFlight'
    Id = db.Column(db.Integer, primary_key = True)
    City = db.Column(db.String(50))
    IATA = db.Column(db.String(3))
    Time = db.Column(db.DateTime())
    Type = db.Column(db.String(30))
    Code = db.Column(db.String(30))
    Gate = db.Column(db.String(4))
    Carrier = db.Column(db.String(4))
    Status = db.Column(db.String(30))

def __init__(self, id, city, iata, time, flight_type, code, gate, carrier, status):
    self.Id = id
    self.City = city
    self.IATA = iata
    self.Time = time
    self.Type = flight_type
    self.Code = code
    self.Gate = gate
    self.Carrier = carrier
    self.Status = status

@app.route('/')
def show_all():
   return render_template('index.html', 
                          flights = Flight.query.order_by(Flight.Time).all())

if __name__ == "__main__":
    db.create_all()
    waitress.serve(app, 
                  host='web-server',
                  port=5000)
    db.close()
