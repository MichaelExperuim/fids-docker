import sys
import socketserver
from hashlib import sha256
from uptime import uptime
import subprocess

password = "C45C01C3885BC08666959321F2BAA506550C313732851F871E977B1CEF564E98"
class MyRequestHandler(socketserver.StreamRequestHandler):
    def successful_connection(self):
        while True:
            self.request.sendall(bytes("Enter a command ('help' to list commands): ", "utf-8"))
            recvd = self.request.recv(1024).decode("utf-8").strip()
            print(recvd)
            
            if recvd.split(" ")[0] == 'help':
                self.request.sendall(bytes("\nhelp  --  lists all commands\ntimeUp -- returns current system uptime\ncheckLog -- returns system log\nbash -- executes bash command following 'bash' with root permissions\nexit -- close tcp connection\n\n", "utf-8"))
            
            elif recvd.split(" ")[0] == 'timeUp':
                self.request.sendall(bytes("\n{} seconds\n\n".format(uptime()), "utf-8"))
            
            elif recvd.split(" ")[0] == 'bash':
                command = recvd.split(" ")[1:]
                process = subprocess.Popen(command, stdout=subprocess.PIPE)
                out = process.communicate()[0]
                # to_send = check_output("sudo " + str(" ".join(recvd.split(" ")[1:])))
                self.request.sendall(bytes("\nBASH COMMAND '{}' RETURNED:\n{}\n".format(" ".join(command), out.decode("utf-8")), "utf-8"))

            elif recvd.split(" ")[0] == "checkLog":
                self.request.sendall(bytes("\n", "utf-8"))
                with open("/var/log/FIDS_Log.txt", 'r') as file:
                    for line in file:
                        self.request.sendall(bytes(line, "utf-8"))
                self.request.sendall(bytes("\n", "utf-8"))

            elif recvd.split(" ")[0] == 'exit':
                self.request.sendall(bytes("\nGoodbye\n", "utf-8"))
                break
            
            else:
                self.request.sendall(bytes("\nInvalid Command\n\n", "utf-8"))
        
        server.request.close()
    def handle(self):
        self.request.sendall(bytes("Enter 4-digit PIN: ", "utf-8"))
        passwd = self.request.recv(64).strip()
        if sha256(passwd.strip()).hexdigest().lower() != password.lower():
            self.request.sendall(bytes("\nInvalid PIN, Goodbye\n", "utf-8"))
            self.request.close()
        else:
            self.request.sendall(bytes("\nWelcome\n\n", "utf-8"))
            self.successful_connection()

if __name__ == "__main__":

    try:
        HOST, PORT = r'0.0.0.0', 12375
        print('STARTING TCP SERVER ON PORT: %s' % PORT, flush=True)    
        server = socketserver.TCPServer((HOST, PORT), MyRequestHandler)
        server.serve_forever()
    
    except Exception as ex:
        
        print(ex,
              flush=True)